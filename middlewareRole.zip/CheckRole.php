<?php

namespace App\Http\Middleware;

use Closure;
use App\User as User;
class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $roles = config('acl');
        $user = User::where('token', $request->input('token'))->get()->first();
        $userRole = $user->roles[0]->name;
        foreach ($roles as $key => $value) {
          if(strtolower($key) === strtolower($userRole)) {
            if($value[0] === '*') {
              return $next($request);
            } else {
              foreach ($value as $route) {
                if('/' . $request->path() === $route) {
                  return $next($request);
                }
              }
            }
          }
        }
        return response()->json([
          'error' => 'Authentication error',
          'errorMessage' => 'Please reconnect'
        ]);
    }
}
