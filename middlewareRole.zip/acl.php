<?php
return [
  'admin' => [
    '*',
  ],
  'user' => [
    '/user',
    '/user/update/{id}',
    '/users',
    '/user/find',
  ]
];
